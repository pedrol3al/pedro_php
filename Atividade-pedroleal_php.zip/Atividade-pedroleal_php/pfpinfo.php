<?php 

phpinfo();

?>