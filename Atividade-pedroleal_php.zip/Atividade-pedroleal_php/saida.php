<?php

print "teste <br>";
print "Olá, mundo <br>\n";
print "Escape 'chars' são os mesmos como em C <br> \n" ;
print "Você pode ter quebra de linhas em uma string <br>";
print 'Uma string pode usar "aspas-duplas".Isso é muito legal! <br>';
print 'Ainda pode-se usar aspas simples dessa forma It\'s cool! <br>';

?>
<br>
<br>
<br>


<?php

echo "teste <br>";
echo "Olá, mundo <br>\n";
echo "Escape 'chars' são os mesmos como em C <br> \n" ;
echo "Você pode ter quebra de linhas em uma string <br>";
echo 'Uma string pode usar "aspas-duplas".Isso é muito legal! <br>';
echo 'Ainda pode-se usar aspas simples dessa forma It\'s cool! <br>';

?>

<?php

echo "<h2 align='center'> O meu programa esta ecoando corretamente no meu servidor PHP"

?>
