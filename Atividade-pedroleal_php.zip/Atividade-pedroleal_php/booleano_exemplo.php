<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php

//Declarando variavel numerica

$umidade = 90;

//Testa se $umidade maior que 90. Retorna um boolean

$Vaichover = ($umidade > 90);

//Testa se $Vaichover é verdadeiro

if($Vaichover){


    echo "Vai chover com toda certeza absoluta da terra!";
}else{

    echo "Não vai chover";
}

?>
    
</body>
</html>