<?php
require("conecta.php");
$conexao = conectadb();

//OBTEM O ID DA IMAGEM URL, GARANTINDO QUE SEJA UM NÚMERO INTEIRO
$id_imagem = isset($_GET['id'])? intval($_GET['id']):0;

//VERIFICA SE O id É VALIDO (MAIOR QUE ZERO)
if($id_imagem > 0){
    //CRIAR QUERY SEGURA USANDO O prepared statement
    $queryExclusao="DELETE FROM tabela_imagem where codigo = ?";

    //PREPARA A QUERY
    $stmt = $conexao->prepare($querySelecionaPorCodigo);
    $stmt->bind_param("i", $id_imagem); //DEFINE O ID COM UM INTEIRO

    //EXECUTA A EXCLUSÃO
    if($stmt->execute()){
        echo "Imagem excluida com sucesso!";
    }else{
        die ("Erro ao excluir a imagem".$stmt->error);
    }

    //FECHA A CONSULTA
    $stmt->close();
}else{
    echo "ID invalido";
}

//REDIRECIONA PARA A INDEX.PHP E GARANTE QUE O SCRIPT PARE
header("Location: index.php");
exit();
?>